/* eslint-disable no-unused-vars */
import React from 'react'


const AllRoutes = () => {
  return (
     <>
     </>
  )
}

export default AllRoutes