// src/MembershipPlans.js
import React from 'react';
import './MembershipPlans.css';

const plans = [
    { name: 'Basic', fee: '₹10,000', features: [true, true, true, false, false, false, false, false, false, false] },
    { name: 'Silver', fee: '₹25,000', features: [true, true, true, false, false, true, false, false, false, false] },
    { name: 'Gold', fee: '₹50,000', features: [true, true, true, true, true, true, true, false, false, false] },
    { name: 'Platinum', fee: '₹1,00,000', features: [true, true, true, true, true, true, true, true, true, true] },
];

const featuresList = [
    'Business Meets',
    'Seminars & Workshops',
    'Industry Voice',
    'Exclusive Dinner with Higherups',
    'VIP Event Invitations',
    'Business Consultations',
    'Policy Advocacy Support',
    'Featured Industry Profile',
    'Leadership Opportunities',
];

const MembershipPlans = () => {
    return (
        <div className="membership-container">
            <h2 className="membership-title">Membership Plans</h2>
            <p className="membership-subtitle">Explore our various levels of industry engagement and benefit.</p>
            <div className="membership-table">
                <div className="membership-column">
                    <div className="membership-feature">Membership Level</div>
                    <div className="membership-feature">Annual Fee (INR)</div>
                    {featuresList.map((feature, index) => (
                        <div key={index} className="membership-feature">
                            {feature}
                        </div>
                    ))}
                </div>
                {plans.map((plan, index) => (
                    <div key={index} className="membership-column">
                        <div className="membership-plan-name">{plan.name}</div>
                        <div className="membership-fee">{plan.fee}</div>
                        {plan.features.map((isAvailable, featureIndex) => (
                            <div key={featureIndex} className="membership-feature">
                                {isAvailable ? <span className="checkmark">✔</span> : '-'}
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MembershipPlans;
