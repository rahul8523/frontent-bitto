import Layer21 from "./Layer-21.png";
import Layer22 from "./Layer-22.png";
import Layer23 from "./Layer-23.png";
import Layer24 from "./Layer-24.png";
import Layer25 from "./Layer-25.png";
import Layer26 from "./Layer-26.png";
import Layer27 from "./Layer-27.png";
import Layer28 from "./Layer-28.png";
import Layer29 from "./Layer-29.png";
import Layer30 from "./Layer-30.png";
import Layer31 from "./Layer-31.png";
import Layer33 from "./Layer-33.png";
import Layer34 from "./Layer-34.png";
import ObjectiveGoals from "./entrepreneur-setting-up-operational-goals-objectives.jpg";



// ICON IMAGE IN bITOcARD 
import BitoImage from "./new-1.png"
import BitoImage1 from "./new-2.png"
import BitoImage2 from "./new-3.png"
import BitoImage3 from "./new-4.png"
import BitoImage4 from "./new-5.png"
import BitoImage5 from "./new-6.png"
import BitoImage6 from "./new-7.png"
import BitoImage7 from "./new-8.png"




export {
  Layer21,
  Layer22,
  Layer23,
  Layer24,
  Layer25,
  Layer26,
  Layer27,
  Layer28,
  Layer29,
  Layer30,
  Layer31,
  Layer33,
  Layer34,
  ObjectiveGoals,
  BitoImage,
  BitoImage1,
  BitoImage2,
  BitoImage3,
  BitoImage4,
  BitoImage5,
  BitoImage6,
  BitoImage7,

};
